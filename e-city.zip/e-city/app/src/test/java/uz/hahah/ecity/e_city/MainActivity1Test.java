package uz.hahah.ecity.e_city;

import static org.junit.Assert.*;

/**
 * Created by valiyar on 4/5/2018.
 */
public class MainActivity1Test {

}