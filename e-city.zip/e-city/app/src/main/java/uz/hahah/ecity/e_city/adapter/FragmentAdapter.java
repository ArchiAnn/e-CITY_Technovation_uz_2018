package uz.hahah.ecity.e_city.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by jason on 4/2/18.
 */

public class FragmentAdapter extends FragmentStatePagerAdapter {
    FragmentManager fragmentManager;

    public FragmentAdapter(FragmentManager fm) {
        super(fm);
        this.fragmentManager = fm;
    }

    private final List<Fragment> mFragmentList = new ArrayList<>();
    private final List<String> mFragmentTitleList = new ArrayList<>();


    @Override
    public Fragment getItem(int i) {
        Fragment fragment = mFragmentList.get(i);

        return fragment;
    }

    @Override
    public int getCount() {
        return mFragmentList.size();
    }

    public FragmentAdapter addFragment(Fragment fragment, String title) {
        mFragmentList.add(fragment);
        mFragmentTitleList.add(title);

        return this;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return mFragmentTitleList.get(position);
    }

    @Override
    public int getItemPosition(Object object) {
        if (object == null) return -1;
        for (Fragment f : mFragmentList) {
            if (object.getClass().isInstance(f)) {
                return mFragmentList.indexOf(f);
            }
        }
        return -1;
    }
}