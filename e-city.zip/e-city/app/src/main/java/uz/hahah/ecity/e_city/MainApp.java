package uz.hahah.ecity.e_city;

import android.app.Application;
import android.content.Context;
import android.support.v7.app.AppCompatDelegate;

import uz.hahah.ecity.e_city.util.PreferenceUtil;

/**
 * Created by jason on 05.02.17.
 */

public class MainApp extends Application {

    private static final String TAG = MainApp.class.getSimpleName();

    private static Context context;

    public static Context getContext() {
        return context;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        context = getApplicationContext();
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        PreferenceUtil.init(getSharedPreferences(getClass().getName(), Context.MODE_PRIVATE));
    }

}
