package uz.hahah.ecity.e_city;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import uz.hahah.ecity.e_city.model.Problem;
import uz.hahah.ecity.e_city.util.PreferenceUtil;

public class MainActivity5 extends AppCompatActivity {
    private Problem problem;

    private TextView mName;
    private TextView mCategory;
    private TextView mDescription;
    private TextView mCreated_at;
    private ImageView mPhoto;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        Intent intent = getIntent();
        String uid = intent.getStringExtra("problem_uid");
        problem = PreferenceUtil.get("problem_" + uid, null, Problem.class);

        if (problem == null) {
            Toast.makeText(this, "Problem is not found!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        mName = findViewById(R.id.name);
        mCategory = findViewById(R.id.category);
        mDescription = findViewById(R.id.description);
        mCreated_at = findViewById(R.id.created_at);
        mPhoto = findViewById(R.id.photo);

        mName.setText(problem.getName());
        mDescription.setText(problem.getDecription());
        mCreated_at.setText(new SimpleDateFormat("dd.MM.yyyy hh:mm").format(problem.getCreatedAt()));

        List<String> selectcategory = new ArrayList<>(Arrays.asList(this
                .getResources()
                .getStringArray(R.array.selectcategory)));
        selectcategory.remove(0);
        Integer index = problem.getCategory() - 1;

        mCategory.setText(index < 0 ? "Not selected" : selectcategory.get(index));
        Picasso.get()
                .load(problem.getPhoto())
                .resize(512, 512)
                .centerCrop()
                .into(mPhoto);
    }
}
