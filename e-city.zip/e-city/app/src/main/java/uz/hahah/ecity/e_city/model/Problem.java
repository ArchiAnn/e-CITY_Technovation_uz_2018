package uz.hahah.ecity.e_city.model;

import java.util.Date;

/**
 * Created by User on 12.04.2018.
 */

public class Problem {
    private String uId;
    // ну мыже както должны узнать кто это сохранял, поетому указываем уникальный айди пользователя поняла)
    private String name;
    private String decription;
    private String photo;
    private Date createdAt;// к примеру вот этот нестандартный класс, это класс времени, если он непоймет скажет ошибка
    private Integer category;
    private Double longditude;
    private Double latitude;

    public Problem() {
    }

    public String getuId() {
        return uId;
    }

    public Problem setuId(String uId) {
        this.uId = uId;
        return this;
    }

    public String getName() {
        return name;
    }

    public Problem setName(String name) {
        this.name = name;
        return this;
    }

    public String getDecription() {
        return decription;
    }

    public Problem setDecription(String decription) {
        this.decription = decription;
        return this;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public Problem setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
        return this;
    }

    public Integer getCategory() {
        return category;
    }

    public Problem setCategory(Integer category) {
        this.category = category;
        return this;
    }

    public Double getLongditude() {
        return longditude;
    }

    public Problem setLongditude(Double longditude) {
        this.longditude = longditude;
        return this;
    }

    public Double getLatitude() {
        return latitude;
    }

    public Problem setLatitude(Double latitude) {
        this.latitude = latitude;
        return this;
    }

    public String getPhoto() {
        return photo;
    }

    public Problem setPhoto(String photo) {
        this.photo = photo;
        return this;
    }
}
