package uz.hahah.ecity.e_city.util;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public abstract class Adapter<T> extends RecyclerView.Adapter<Adapter.ViewHolder> {


    protected List<T> items;
    protected Context context;

    public Adapter(Context context) {
        this(context, new ArrayList<T>());
    }

    public Adapter(Context context, List<T> items) {
        this.items = items;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return getViewHolder(parent, viewType);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.bindItem(items.get(position), position);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public abstract void refresh();


    public <E extends Adapter> E addAll(List<T> list) {
        this.items.addAll(list);
        return (E) this;
    }

    public <E extends Adapter> E add(T single) {
        this.items.add(single);
        return (E) this;
    }

    public List<T> getItems() {
        return items;
    }

    public <E extends Adapter> E clear() {
        this.items.clear();
        return (E) this;
    }

    public abstract ViewHolder<T> getViewHolder(ViewGroup parent, int viewType);

    public Context getContext() {
        return context;
    }

    public interface OnItemClick<T> {
        void onItemClick(T item, int position);
    }

    protected static abstract class ViewHolder<T> extends RecyclerView.ViewHolder {

        protected T item;
        protected int position;

        public ViewHolder(ViewGroup parent, @LayoutRes int id) {
            super(LayoutInflater.from(parent.getContext())
                    .inflate(id, parent, false));
        }

        protected void bindItem(T item, int position) {
            this.item = item;
            this.position = position;
            this.bind(item, position);
        }

        public abstract void bind(T item, int position);
    }

}