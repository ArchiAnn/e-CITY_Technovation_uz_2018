package uz.hahah.ecity.e_city.util;

import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.lang.reflect.Modifier;

/**
 * Created by Jason on 01.06.2017.
 */

public class PreferenceUtil {

    private static SharedPreferences mSharedPreferences;
    private static Gson gson;

    public static void init(SharedPreferences sharedPreferences) {
        mSharedPreferences = sharedPreferences;
    }

    public static void set(String key, String val) {
        synchronized (mSharedPreferences) {
            mSharedPreferences.edit()
                    .putString(key, val)
                    .apply();
        }
    }

    public static String getString(String key, String default_) {
        synchronized (mSharedPreferences) {
            return mSharedPreferences.getString(key, default_);
        }
    }

    public static float getFloat(String key, float default_) {
        synchronized (mSharedPreferences) {
            return mSharedPreferences.getFloat(key, default_);
        }
    }

    public static void set(String key, float val) {
        synchronized (mSharedPreferences) {
            mSharedPreferences.edit()
                    .putFloat(key, val)
                    .apply();
        }
    }

    public static void set(String key, long val) {
        synchronized (mSharedPreferences) {
            mSharedPreferences.edit()
                    .putLong(key, val)
                    .apply();
        }
    }

    public static void set(String key, int val) {
        synchronized (mSharedPreferences) {
            mSharedPreferences.edit()
                    .putInt(key, val)
                    .apply();
        }
    }

    public static void set(String key, boolean val) {
        synchronized (mSharedPreferences) {
            mSharedPreferences.edit()
                    .putBoolean(key, val)
                    .apply();
        }
    }

    public static int getInt(String key, int default_) {
        synchronized (mSharedPreferences) {
            return mSharedPreferences.getInt(key, default_);
        }
    }

    public static boolean getBool(String key, boolean default_) {
        synchronized (mSharedPreferences) {
            return mSharedPreferences.getBoolean(key, default_);
        }
    }

    public static long getLong(String key, long default_) {
        synchronized (mSharedPreferences) {
            return mSharedPreferences.getLong(key, default_);
        }
    }


    public static <T> T get(String key, T aValueDefault, Class<T> aClass) {
        String value = mSharedPreferences.getString(key, null);
        return value == null ? aValueDefault :
                value == aValueDefault || value.length() == 0 ? aValueDefault :
                        loadGson().fromJson(value, aClass);
    }

    public static <T> void set(String key, T aValue, Class<T> aClass) {
        SharedPreferences.Editor editor = mSharedPreferences.edit();
        editor.putString(key, aValue == null ? null : loadGson().toJson(aValue, aClass));
        editor.apply();
    }

    public static Gson loadGson() {
        if (gson == null)
            gson = new GsonBuilder()
                    .excludeFieldsWithModifiers(Modifier.FINAL, Modifier.TRANSIENT, Modifier.STATIC)
                    .create();
        return gson;
    }
}
