package uz.hahah.ecity.e_city.fragment;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.Date;
import java.util.List;

import uz.hahah.ecity.e_city.MainActivity4;
import uz.hahah.ecity.e_city.R;

import static android.content.Context.LOCATION_SERVICE;

/**
 * Created by jason on 4/2/18.
 */


public class ProblemMapFragment extends Fragment {
    //mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
    public static final String TAG = ProblemMapFragment.class.getSimpleName();
    public static final Integer LOCATION_ACCESS = 1999;
    private FloatingActionButton fab;
    private MapView mapView;
    private GoogleMap googleMap;
    private LocationManager locationManager;

    /* protected void createLocationRequest() {
         LocationRequest mLocationRequest = new LocationRequest();
         mLocationRequest.setInterval(10000);
         mLocationRequest.setFastestInterval(5000);
         mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
     }
     LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
             .addLocationRequest(mLocationRequest);

     SettingsClient client = LocationServices.getSettingsClient(this);
     Task<LocationSettingsResponse> task = client.checkLocationSettings(builder.build());*/


    private LocationListener locationListener = new LocationListener() {

        @Override
        public void onLocationChanged(Location location) {
//            showLocation(location);
        }

        @Override
        public void onProviderDisabled(String provider) {
            checkEnabled();
        }

        @SuppressLint("MissingPermission")
        @Override
        public void onProviderEnabled(String provider) {
            checkEnabled();
//            showLocation(locationManager.getLastKnownLocation(provider));
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
            if (provider.equals(LocationManager.GPS_PROVIDER)) {
                Toast.makeText(getContext(), "Status: " + String.valueOf(status), Toast.LENGTH_SHORT).show();
            } else if (provider.equals(LocationManager.NETWORK_PROVIDER)) {
                Toast.makeText(getContext(), "Status: " + String.valueOf(status), Toast.LENGTH_SHORT).show();
            }
        }
    };


    @Override
    public View onCreateView(LayoutInflater i, ViewGroup g, Bundle bundle) {
        View v = i.inflate(R.layout.fragment_problem_map, g, false);
        mapView = v.findViewById(R.id.mapView);
        locationManager = (LocationManager) getContext().getSystemService(LOCATION_SERVICE);
        fab = v.findViewById(R.id.floatingActionButton3);
        mapView.onCreate(bundle);

//        UiSettings.setMyLocationButtonEnabled(false)


        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (googleMap == null)
                    return;

                // Getting Current Location
                if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                        ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_ACCESS);

                    return;
                }


                Location location = getLastKnownLocation();
                Toast.makeText(getContext(), "location = " + location, Toast.LENGTH_SHORT).show();
                startActivityByLocation(location);
                startActivity(new Intent(getContext(), MainActivity4.class));
            }
        });
        mapView.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(GoogleMap googleMap_) {
                googleMap = googleMap_;
                googleMap.getUiSettings().setMyLocationButtonEnabled(true);
                double latitude = 41.311081;
                double longitude = 69.240562;

                MarkerOptions marker = new MarkerOptions().position(new LatLng(latitude, longitude)).title("Marker");

                googleMap.addMarker(marker);

                CameraPosition cameraPosition = new CameraPosition.Builder().target(new LatLng(41.311081, 69.240562)).zoom(15).build();

                googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                googleMap.getUiSettings().setZoomControlsEnabled(true); // true to enable
                googleMap.getUiSettings().setZoomGesturesEnabled(true);
                googleMap.getUiSettings().setCompassEnabled(true);
                googleMap.getUiSettings().setMyLocationButtonEnabled(true);
                googleMap.getUiSettings().setRotateGesturesEnabled(true);
            }
        });
        return v;
    }

    private Location getLastKnownLocation() {
        List<String> providers = locationManager.getProviders(true);
        Location bestLocation = null;
        for (String provider : providers) {
            @SuppressLint("MissingPermission")
            Location l = locationManager.getLastKnownLocation(provider);
            if (l == null) {
                continue;
            }
            if (bestLocation == null || l.getAccuracy() < bestLocation.getAccuracy()) {
                // Found best last known location: %s", l);
                bestLocation = l;
            }
        }
        return bestLocation;
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == LOCATION_ACCESS) {
            if (permissions.length == 1 &&
                    permissions[0] == Manifest.permission.ACCESS_FINE_LOCATION &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                googleMap.setMyLocationEnabled(true);
                Location location = getLastKnownLocation();
                startActivityByLocation(location);
            }
        }
    }


    private void startActivityByLocation(Location location) {
        if (location == null) {
            Toast.makeText(getContext(), "No Location!", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent i = new Intent(getContext(), MainActivity4.class);
        i.putExtra("latitude", location.getLatitude());
        i.putExtra("longitude", location.getLongitude());
        startActivity(i);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

    @Override
    public void onResume() {
        super.onResume();
        mapView.onResume();
        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                1000 * 10, 10, locationListener);
        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(
                LocationManager.NETWORK_PROVIDER, 1000 * 10, 10,
                locationListener);
        checkEnabled();
    }

    @Override
    public void onPause() {
        super.onPause();
        mapView.onPause();
        locationManager.removeUpdates(locationListener);
    }

   /* private void showLocation(Location location) {
        if (location == null)
            return;
        if (location.getProvider().equals(LocationManager.GPS_PROVIDER)) {
            Toast.makeText(getContext(), "formatLocation(location) = " + formatLocation(location), Toast.LENGTH_SHORT).show();
        } else if (location.getProvider().equals(
                LocationManager.NETWORK_PROVIDER)) {
            Toast.makeText(getContext(), "formatLocation(location) = " + formatLocation(location), Toast.LENGTH_SHORT).show();
        }
    }*/

    @SuppressLint("DefaultLocale")
    private String formatLocation(Location location) {
        if (location == null)
            return "";
        return String.format(
                "Coordinates: lat = %1$.4f, lon = %2$.4f, time = %3$tF %3$tT",
                location.getLatitude(), location.getLongitude(), new Date(
                        location.getTime()));
    }

    @SuppressLint("SetTextI18n")
    private void checkEnabled() {
      /*  Toast.makeText(getContext(), "Enabled: "
                + locationManager
                .isProviderEnabled(LocationManager.GPS_PROVIDER), Toast.LENGTH_SHORT).show();
        Toast.makeText(getContext(), "Enabled: "
                + locationManager
                .isProviderEnabled(LocationManager.NETWORK_PROVIDER), Toast.LENGTH_SHORT).show();*/
    }

    /*public void onClickLocationSettings(View view) {
        startActivity(new Intent(
                android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
    }*/


}
