package uz.hahah.ecity.e_city;


import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.util.Date;
import java.util.UUID;

import uz.hahah.ecity.e_city.model.Problem;

public class MainActivity4 extends AppCompatActivity {


    final int PICK_IMAGE_REQUEST = 71;
    final int PICK_IMAGE_ACCESS = 99;
    private EditText inputproblem_name;
    private EditText inputproblem_description;
    private Button button;
    private Spinner category;
    private MapView mapView;
    private FirebaseStorage storage;
    private StorageReference storageReference;
    private GoogleMap googleMap;
    private DatabaseReference mDatabase;
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    private Bitmap bitmap;
    private String problem_photo;
    private Uri filePath;
    private Double latitude;
    private Double longitude;


    private void dispatchTakePictureIntent() {
        if (Build.VERSION.SDK_INT >= 23 &&
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, PICK_IMAGE_ACCESS);
            return;
        }

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, PICK_IMAGE_REQUEST);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PICK_IMAGE_ACCESS) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                dispatchTakePictureIntent();
            } else {
                Snackbar.make(this.getWindow().getDecorView(), "CAMERA permission denied!", Snackbar.LENGTH_LONG).show();
            }

        }
    }

    private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            filePath = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                uploadImage();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void uploadImage() {
        if (filePath != null) {
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Uploading...");
            progressDialog.show();

            StorageReference ref = storageReference.child("images/" + UUID.randomUUID().toString());
            ref.putFile(filePath)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            problem_photo = taskSnapshot.getDownloadUrl().toString();
                            progressDialog.dismiss();
                            Snackbar.make(getWindow().getDecorView(), "Uploaded: " + problem_photo, Snackbar.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();
                            Snackbar.make(getWindow().getDecorView(), "Failed " + e.getMessage(), Snackbar.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot
                                    .getTotalByteCount());
                            progressDialog.setMessage("Uploaded " + (int) progress + "%");
                        }
                    });
        } else {
            Snackbar.make(getWindow().getDecorView(), "Picture is not selected! ", Snackbar.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        button = findViewById(R.id.send);
        category = findViewById(R.id.spinner);

        mDrawerLayout = findViewById(R.id.drawer);
        mToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.open, R.string.close);
        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        inputproblem_name = findViewById(R.id.problem_name);
        inputproblem_description = findViewById(R.id.problem_description);
        mapView = findViewById(R.id.mapView2);
        mapView.onCreate(savedInstanceState);

        Intent intent = getIntent();
        latitude = intent.getDoubleExtra("latitude", 41.311081);
        longitude = intent.getDoubleExtra("longitude", 69.240562);

        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();


        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View view) {
                final String problem_name = inputproblem_name.getText().toString().trim();
                final String problem_description = inputproblem_description.getText().toString().trim();
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

                if (category.getSelectedItemPosition() == 0) {
                    Snackbar.make(getWindow().getDecorView(), "Pease select the Category!", Snackbar.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(problem_name)) {
                    Snackbar.make(getWindow().getDecorView(), "Enter Problem Name!", Snackbar.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(problem_description)) {
                    Snackbar.make(getWindow().getDecorView(), "Enter Problem Description ", Snackbar.LENGTH_SHORT).show();
                    return;
                }

                if (user == null || TextUtils.isEmpty(user.getUid())) {
                    Snackbar.make(getWindow().getDecorView(), "You have no account, Please register! ", Snackbar.LENGTH_SHORT).show();
                    return;
                }

                if (problem_photo == null || TextUtils.isEmpty(problem_photo)) {
                    Snackbar.make(getWindow().getDecorView(), "Please choose the picture of problem! ", Snackbar.LENGTH_SHORT).show();
                    return;
                }

                Toast.makeText(getApplicationContext(), "Start announcing Problem!", Toast.LENGTH_SHORT).show();
                DatabaseReference problems = mDatabase.child("problems");
                String key = problems.push().getKey();
                problems.child(key).setValue(new Problem()
                        .setuId(user.getUid())
                        .setName(problem_name)
                        .setDecription(problem_description)
                        .setPhoto(problem_photo)
                        .setCreatedAt(new Date())
                        .setCategory(category.getSelectedItemPosition())
                        .setLatitude(latitude)
                        .setLongditude(longitude))
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(MainActivity4.this,
                                        "The problem is saved ",
                                        Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(view.getContext(), MainActivity3.class));
                                finish();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(MainActivity4.this,
                                        "The problem is not saved: " + e.getMessage(),
                                        Toast.LENGTH_SHORT).show();
                            }
                        });

            }
        });

        mapView.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(GoogleMap googleMap_) {
                googleMap = googleMap_;

                MarkerOptions marker = new MarkerOptions()
                        .position(new LatLng(latitude, longitude))
                        .title("Marker");

                googleMap.addMarker(marker);

                CameraPosition cameraPosition = new CameraPosition.Builder()
                        .target(new LatLng(latitude, longitude))
                        .zoom(15)
                        .build();

                googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                googleMap.getUiSettings().setZoomControlsEnabled(true);
                googleMap.getUiSettings().setZoomGesturesEnabled(true);
                googleMap.getUiSettings().setCompassEnabled(true);
                googleMap.getUiSettings().setMyLocationButtonEnabled(true);
                googleMap.getUiSettings().setRotateGesturesEnabled(true);
            }
        });

    }


    @Override
    protected void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }


    public void add_photo(final View view) {

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity4.this);
        builder.setTitle(R.string.camera_or_gallery);
        builder.setItems(new String[]{
                getString(R.string.camera),
                getString(R.string.gallery)
        }, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                switch (i) {
                    case 0:
                        dispatchTakePictureIntent();
                        break;
                    case 1:
                        chooseImage();
                        break;
                }
            }
        });
        builder.create().show();
    }

    public void show_photo(View view) {
        if (bitmap == null) {
            Snackbar.make(view, "Sorry, first you should choose the image!", Snackbar.LENGTH_LONG).show();
            return;
        }
        AlertDialog.Builder imageDialog = new AlertDialog.Builder(this);
        imageDialog.setTitle("Фотография");
        ImageView showImage = new ImageView(this);
        showImage.setImageBitmap(bitmap);
        imageDialog.setView(showImage);
        imageDialog.setPositiveButton(R.string.close, null);
        imageDialog.show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
