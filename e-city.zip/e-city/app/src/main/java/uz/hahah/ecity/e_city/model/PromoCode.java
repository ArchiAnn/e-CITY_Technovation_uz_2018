package uz.hahah.ecity.e_city.model;

import java.util.Date;

/**
 * Created by Jason on 4/23/2018.
 */

public class PromoCode {
    private String uid;
    private String code;
    private Date created;
    private Boolean active;

    public String getUid() {
        return uid;
    }

    public PromoCode setUid(String uid) {
        this.uid = uid;
        return this;
    }

    public String getCode() {
        return code;
    }

    public PromoCode setCode(String code) {
        this.code = code;
        return this;
    }

    public Date getCreated() {
        return created;
    }

    public PromoCode setCreated(Date created) {
        this.created = created;
        return this;
    }

    public Boolean getActive() {
        return active;
    }

    public PromoCode setActive(Boolean active) {
        this.active = active;
        return this;
    }
}
