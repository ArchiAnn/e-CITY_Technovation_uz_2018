package uz.hahah.ecity.e_city.util;

/**
 * Created by Jason on 4/23/2018.
 */

public enum Role {
    USER,
    GOVERNMENT,
    MODERATOR,
    ADMIN;
}
