package uz.hahah.ecity.e_city.model;

import uz.hahah.ecity.e_city.util.Role;

/**
 * Created by jason on 4/12/18.
 */

public class User {
    private String uId;

    private String first_name;
    private String last_name;
    private String phone;
    private String email;
    private String promo_code;
    private Role role;

    public User(String uId, String first_name, String last_name, String phone, String email, String promo_code, Role role) {
        this.uId = uId;
        this.first_name = first_name;
        this.last_name = last_name;
        this.phone = phone;
        this.email = email;
        this.promo_code = promo_code;
        this.role = role;
    }

    public User() {
    }

    public String getuId() {
        return uId;
    }

    public User setuId(String uId) {
        this.uId = uId;
        return this;
    }

    public String getFirst_name() {
        return first_name;
    }

    public User setFirst_name(String first_name) {
        this.first_name = first_name;
        return this;
    }

    public String getLast_name() {
        return last_name;
    }

    public User setLast_name(String last_name) {
        this.last_name = last_name;
        return this;
    }

    public String getPhone() {
        return phone;
    }

    public User setPhone(String phone) {
        this.phone = phone;
        return this;
    }

    public String getEmail() {
        return email;
    }

    public User setEmail(String email) {
        this.email = email;
        return this;
    }

    public String getPromo_code() {
        return promo_code;
    }

    public User setPromo_code(String promo_code) {
        this.promo_code = promo_code;
        return this;
    }

    public Role getRole() {
        return role;
    }

    public User setRole(Role role) {
        this.role = role;
        return this;
    }
}
