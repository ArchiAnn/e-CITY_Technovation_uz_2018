package uz.hahah.ecity.e_city;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import org.jetbrains.annotations.Nullable;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import uz.hahah.ecity.e_city.model.User;
import uz.hahah.ecity.e_city.util.Role;


public class MainActivity2 extends AppCompatActivity {
    private EditText inputEmail;
    private EditText inputPassword;
    private EditText inputPromocode;
    private EditText inputRepassword;
    private EditText inputPhone;
    private EditText inputLastname;
    private EditText inputFirstname;
    private Button signUp;
    private FirebaseAuth auth;
    private CheckBox mCheckBox;
    private String ifGov;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        auth = FirebaseAuth.getInstance();
        signUp = findViewById(R.id.sign_up);
        mCheckBox = findViewById(R.id.checkBox);

        inputFirstname = findViewById(R.id.input_firstname);
        inputLastname = findViewById(R.id.input_lastname);
        inputEmail = findViewById(R.id.input_email);
        inputPhone = findViewById(R.id.input_phone);
        inputPassword = findViewById(R.id.input_password);
        inputRepassword = findViewById(R.id.input_repassword);
        inputPromocode = findViewById(R.id.input_promocode);

        if (inputPromocode.getText().toString() == "1111"){
            ifGov = "true";
        }
        else ifGov = "false";

        TextView textView = findViewById(R.id.text_agreement);
        String text = "I agree with rules";
        SpannableString ss = new SpannableString(text);
        ClickableSpan clickableSpan1 = new ClickableSpan() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder a_builder = new AlertDialog.Builder(MainActivity2.this);

                a_builder.setTitle("Rules\n" +
                        "        Please write about really existing problems\n" +
                        "        Please don\\'t try to cheat\n" +
                        "        Please be polite and do not offend other users and government\n" +
                        "        Please send relevant photos\n" +
                        "        Please give us accurate information about location\n" +
                        "        Remember we are trying to help!\n" +
                        "        //for technovation judges: enter 1111 as promo code to register as an authority")
                        .setMessage("Rules\n" +
                                "        Please write about really existing problems\n" +
                                "        Please don\\'t try to cheat\n" +
                                "        Please be polite and do not offend other users and government\n" +
                                "        Please send relevant photos\n" +
                                "        Please give us accurate information about location\n" +
                                "        Remember we are trying to help!\n" +
                                "        //for technovation judges: enter 1111 as promo code to register as an authority")
                        .setNeutralButton("Ok!", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }

                        });
                AlertDialog alert = a_builder.create();
                alert.show();
                inputEmail = (EditText) findViewById(R.id.input_email);
                signUp = (Button) findViewById(R.id.sign_up);
                signUp.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String validemail = "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" + "\\@" + "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" + "(" + "\\." + "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" + ")+";
                        String email = inputEmail.getText().toString();
                        Matcher matcher = Pattern.compile(validemail).matcher(email);

                        if (matcher.matches()) {
                            Toast.makeText(getApplicationContext(), "True", Toast.LENGTH_SHORT);

                        } else {
                            Toast.makeText(getApplicationContext(), "Enter Valid Email-ID", Toast.LENGTH_SHORT);
                        }

                    }
                });


            }
        };
        ss.setSpan(clickableSpan1, 13, 18, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView.setText(ss);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
    }

    public void onClickSingup(final View view) {

        final String firstname = inputFirstname.getText().toString().trim();
        final String lastname = inputLastname.getText().toString().trim();
        final String email = inputEmail.getText().toString().trim();
        final String phone = inputPhone.getText().toString().trim();
        final String password = inputPassword.getText().toString().trim();
        final String repassword = inputRepassword.getText().toString().trim();
        final String promocode = inputPromocode.getText().toString().trim();
        ifGov.trim();

        if (TextUtils.isEmpty(firstname)) {
            Toast.makeText(getApplicationContext(), "Enter First Name!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(lastname)) {
            Toast.makeText(getApplicationContext(), "Enter Last Name", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(getApplicationContext(), "Enter email address!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(phone)) {
            Toast.makeText(getApplicationContext(), "Enter Phone!", Toast.LENGTH_SHORT).show();
            return; //учесть,что нумер тоже используют единожды!
        }
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(getApplicationContext(), "Enter password!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(repassword)) {
            Toast.makeText(getApplicationContext(), "Enter Confirm password!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (password.length() < 6) {
            Toast.makeText(getApplicationContext(), "Password too short, enter minimum 6 characters!", Toast.LENGTH_SHORT).show();
            return;
        }
        if(!mCheckBox.isChecked()){
            Toast.makeText(MainActivity2.this,"Check rules first!",Toast.LENGTH_SHORT).show();
            return;


        }
        Toast.makeText(getApplicationContext(), "Start registering User!", Toast.LENGTH_SHORT).show();

        inputRepassword.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
                String strPass1 = inputPassword.getText().toString();
                String strPass2 = inputRepassword.getText().toString();
                if (strPass1.equals(strPass2)) {
                    Toast.makeText(MainActivity2.this,"Passwords match", Toast.LENGTH_SHORT);
                } else {
                    Toast.makeText(MainActivity2.this,"Passwords don`t match", Toast.LENGTH_SHORT);
                    return;


                }
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
        });


//куд
        /*public void afterTextChanged(Editable s) {

            System.out.println(s.toString());
            String newPass = inputPassword.getText().toString();
            String confirmPass = inputRepassword.getText().toString();

            if (!confirmPass.equals("") == !newPass.equals(confirmPass) && newPass.length() == confirmPass.length()) {
                Toast.makeText(MainActivity2.this, "Choose same as New Password", Toast.LENGTH_SHORT).show();
            }
        } */
        // и это тоже


        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);
        progressDialog.show();


        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(MainActivity2.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (!task.isSuccessful()) {
                            Toast.makeText(MainActivity2.this,
                                    "Authentication failed." + task.getException().getLocalizedMessage(),
                                    Toast.LENGTH_SHORT).show();
                            progressDialog.dismiss();
                            return;
                        }

                        Role role = "1111".equals(promocode) ? Role.GOVERNMENT : Role.USER;

                        String uId = task.getResult().getUser().getUid();
                        FirebaseDatabase
                                .getInstance()
                                .getReference("users")
                                .child(uId)
                                .setValue(new User(uId, firstname, lastname, email, phone, promocode, role))
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        Toast.makeText(MainActivity2.this,
                                                "Registration success.",
                                                Toast.LENGTH_SHORT).show();
                                        startActivity(new Intent(view.getContext(), MainActivity1.class));
                                        finish();
                                        progressDialog.dismiss();
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(MainActivity2.this,
                                                "Authentication failed: " + e.getMessage(),
                                                Toast.LENGTH_SHORT).show();
                                        progressDialog.dismiss();
                                    }
                                });


                    }
                });
    }
}