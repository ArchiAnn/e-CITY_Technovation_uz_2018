package uz.hahah.ecity.e_city.fragment;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.razerdp.widget.animatedpieview.AnimatedPieView;
import com.razerdp.widget.animatedpieview.AnimatedPieViewConfig;
import com.razerdp.widget.animatedpieview.data.SimplePieInfo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import uz.hahah.ecity.e_city.MainActivity8;
import uz.hahah.ecity.e_city.R;
import uz.hahah.ecity.e_city.model.Problem;

/**
 * Created by jason on 4/2/18.
 */


public class ProblemListFragmentForAuthority extends Fragment {
    public static final String TAG = ProblemListFragmentForAuthority.class.getSimpleName();
    private List<Problem> problems = new ArrayList<>();
    private ListView items;
    private ArrayAdapter<String> arrayAdapter;
    private String something_ID;
    private int[] category_colors;
    private List<String> selectcategory;
    private AnimatedPieView pieChart;

    public static int colorWithAlpha(int color, float ratio) {
        int newColor = 0;
        int alpha = Math.round(Color.alpha(color) * ratio);
        int r = Color.red(color);
        int g = Color.green(color);
        int b = Color.blue(color);
        newColor = Color.argb(alpha, r, g, b);
        return newColor;
    }


    private static int darkenColorMath(int color, double fraction) {
        return (int) Math.max(color - (color * fraction), 0);
    }


    public static int darkenColor(int color, double fraction) {
        int red = Color.red(color);
        int green = Color.green(color);
        int blue = Color.blue(color);
        red = darkenColorMath(red, fraction);
        green = darkenColorMath(green, fraction);
        blue = darkenColorMath(blue, fraction);
        int alpha = Color.alpha(color);

        return Color.argb(alpha, red, green, blue);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup g, Bundle b) {
        View v = inflater.inflate(R.layout.fragment_problem_list, g, false);
        items = v.findViewById(R.id.items);
        //items.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, problems ));

        arrayAdapter = new ArrayAdapter<String>(inflater.getContext(), android.R.layout.simple_list_item_1, new ArrayList<String>());
        items.setAdapter(arrayAdapter);
        category_colors = getContext().getResources().getIntArray(R.array.category_colors);
        pieChart = v.findViewById(R.id.chart);

        selectcategory = new ArrayList<>(Arrays.asList(getContext()
                .getResources()
                .getStringArray(R.array.selectcategory)));
        selectcategory.remove(0);

        //todo Anna вот так будет правильнее
        items.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                startActivity(new Intent(getContext(), MainActivity8.class));
            }
        });
/*
        private void startActivityByIDD(String i) {
            Intent i = new Intent(getContext(), MainActivity4.class);
            i.putExtra("latitude", location.getLatitude());
            i.putExtra("longitude", location.getLongitude());
            startActivity(i);
        }
        */
        FirebaseDatabase.getInstance()
                .getReference("problems")
                .addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                        Log.d(TAG, "onChildAdded");
                        Problem problem = dataSnapshot.getValue(Problem.class);
                        addProblemPercentage(problem);
                        something_ID = problem.getuId();
                        arrayAdapter.add(problem.getName());
                        arrayAdapter.notifyDataSetChanged();
                    }

                    /*protected void onListItemClick(ListView l, View v, int position, long id) {
                        super.onListItemClick(l, v, position, id);
                        Object o = this.getListAdapter().getItem(position);
                        String pen = o.toString();
                        Toast.makeText(this, "You have chosen the pen: " + " " + pen, Toast.LENGTH_LONG).show();
                    }*/ //nope
                    /* items.setOnItemClickListener(new OnItemClickListener(){
                            @Override
                            public void onItemClick(arrayAdapter<?> arg0, View view,
                            int position, long id) {
                            startActivity(new Intent(this, MainActivity5.class));
                        }
                    }*/
                    @Override
                    public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                        Log.d(TAG, "onChildChanged");
                    }

                    @Override
                    public void onChildRemoved(DataSnapshot dataSnapshot) {
                        Log.d(TAG, "onChildRemoved");
                    }

                    @Override
                    public void onChildMoved(DataSnapshot dataSnapshot, String s) {
                        Log.d(TAG, "onChildMoved");
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Log.d(TAG, "onCancelled");
                    }
                });

        return v;
    }

    private void addProblemPercentage(Problem problem) {
        problems.add(problem);
        Integer countOfProblem = problems.size();

        int[] categoryCounts = new int[selectcategory.size()];

        for (Problem problem_ : problems) {
            Integer category_index = problem_.getCategory() - 1;
            categoryCounts[category_index]++;
        }

        AnimatedPieViewConfig config = new AnimatedPieViewConfig().startAngle(-90)
                .textMargin(2)
                .textGravity(AnimatedPieViewConfig.ABOVE)
                .drawText(true)
                .splitAngle(0.5f)
                .duration(2000)
                .textSize(40);



        for (int i = 0; i < categoryCounts.length; i++) {
            String category = selectcategory.get(i);
            Integer percent = 100 * categoryCounts[i] / countOfProblem;

            config.addData(new SimplePieInfo(percent,
                    colorWithAlpha(category_colors[i], 35),
                    category + " " + percent + "%"));
        }


        pieChart.applyConfig(config);
        pieChart.start();
    }

}