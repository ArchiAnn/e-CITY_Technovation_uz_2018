package uz.hahah.ecity.e_city.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import uz.hahah.ecity.e_city.MainActivity5;
import uz.hahah.ecity.e_city.R;
import uz.hahah.ecity.e_city.model.Problem;
import uz.hahah.ecity.e_city.util.Adapter;
import uz.hahah.ecity.e_city.util.PreferenceUtil;

public class RolesAdapter extends Adapter<Problem> {


    public RolesAdapter(Context context) {
        super(context);
    }

    @Override
    public void refresh() {

    }

    @Override
    public ViewHolder<Problem> getViewHolder(ViewGroup parent, int viewType) {
        return new Holder(parent);
    }

    class Holder extends ViewHolder<Problem> {

        TextView mTitle;
//        TextView mSubTitle;

        public Holder(ViewGroup parent) {
            super(parent, R.layout.item_problem);
            mTitle = itemView.findViewById(R.id.title);
        }


        @Override
        public void bind(final Problem item, final int position) {
//            mSelectCheckBox.setChecked(userId == item.getId());

            mTitle.setText(String.format("%s", item.getName()));
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    PreferenceUtil.set("problem_" + item.getuId(), item, Problem.class);
                    Intent i = new Intent(getContext(), MainActivity5.class);
                    i.putExtra("problem_uid", item.getuId());
                    getContext().startActivity(i);
                }
            });

//            mSubTitle.setText(item.description);
        }
    }
}