package uz.hahah.ecity.e_city;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import uz.hahah.ecity.e_city.model.User;
import uz.hahah.ecity.e_city.util.LocaleUtils;
import uz.hahah.ecity.e_city.util.PreferenceUtil;
import uz.hahah.ecity.e_city.util.Role;


public class MainActivity1 extends AppCompatActivity {
    private static final String TAG = MainActivity1.class.getSimpleName();

    private FirebaseAuth mAuth;
    private EditText entEmail;
    private EditText entPassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAuth = FirebaseAuth.getInstance();
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null) {
            startActivityByUid(user.getUid());
            return;
        }

        setContentView(R.layout.activity_main1);

        entEmail = findViewById(R.id.edit_email);
        entPassword = findViewById(R.id.edit_password);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.language, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.language_en:
                LocaleUtils.updateLanguage(this, "en");
                recreate();
                return true;
            case R.id.language_ru:
                LocaleUtils.updateLanguage(this, "ru");
                recreate();
                return true;
            case R.id.language_uz:
                LocaleUtils.updateLanguage(this, "uz");
                recreate();
                return true;
/*            case R.id.language_kz:
                LocaleUtils.updateLanguage(this, "kz");
                recreate();
                return true;*/
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void onClickSignUp(View v) {
        startActivity(new Intent(this, MainActivity2.class));
    }

    public void onClickEnter(View v) {
        final String email = entEmail.getText().toString().trim();
        final String password = entPassword.getText().toString().trim();

        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Snackbar.make(v, "Enter Email!", Snackbar.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            Snackbar.make(v, "Enter Password", Snackbar.LENGTH_SHORT).show();
            return;
        }

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Snackbar.make(getWindow().getDecorView(), "Авторизация успешна", Snackbar.LENGTH_SHORT).show();
                            final String uid = task.getResult().getUser().getUid();
                            FirebaseDatabase
                                    .getInstance()
                                    .getReference("users")
                                    .child(uid)
                                    .addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(DataSnapshot dataSnapshot) {
                                            User user = dataSnapshot.getValue(User.class);
                                            if (user == null) {
                                                final User user_ = new User(uid, "", "", email, "", null, Role.USER);
                                                FirebaseDatabase
                                                        .getInstance()
                                                        .getReference("users")
                                                        .child(uid)
                                                        .setValue(new User(uid, "", "", email, "", null, Role.USER))
                                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                            @Override
                                                            public void onSuccess(Void aVoid) {
                                                                PreferenceUtil.set(uid, user_, User.class);
                                                                startActivityByUid(uid);
                                                                progressDialog.dismiss();
                                                            }
                                                        })
                                                        .addOnFailureListener(new OnFailureListener() {
                                                            @Override
                                                            public void onFailure(@NonNull Exception e) {
                                                                Toast.makeText(MainActivity1.this,
                                                                        "Authentication failed: " + e.getMessage(),
                                                                        Toast.LENGTH_SHORT).show();
                                                                progressDialog.dismiss();
                                                            }
                                                        });
                                            } else {
                                                PreferenceUtil.set(uid, user, User.class);
                                                startActivityByUid(uid);
                                                progressDialog.dismiss();
                                            }

                                        }

                                        @Override
                                        public void onCancelled(DatabaseError databaseError) {
                                            progressDialog.dismiss();
                                        }
                                    });

                        } else {
                            Snackbar.make(getWindow().getDecorView(), "Авторизация провалена: " + task.getException().getLocalizedMessage(), Snackbar.LENGTH_SHORT).show();
                            progressDialog.dismiss();
                        }

                    }
                });
    }

    private void startActivityByUid(String uid) {
        User user = PreferenceUtil.get(uid, null, User.class);
        if (user == null) {
            PreferenceUtil.set(uid, new User(uid, "", "", "", "", null, Role.USER), User.class);
            startActivity(MainActivity3.class);
        } else
            switch (user.getRole()) {
                case USER:
                    startActivity(MainActivity3.class);
                    break;
                case GOVERNMENT:
                    startActivity(MainActivity7.class);
                    break;
            }
    }

    public void startActivity(Class<? extends Activity> activityClass) {
        startActivity(new Intent(MainActivity1.this, activityClass));
        finish();
    }

    @Override
    public void recreate() {
        if (android.os.Build.VERSION.SDK_INT >= 11) {
            super.recreate();
        } else {
            startActivity(getIntent());
            finish();
        }
    }


}