package uz.hahah.ecity.e_city;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by User on 14.04.2018.
 */

public class MainActivity8 extends AppCompatActivity { //= ма5


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main8);
    }
}
