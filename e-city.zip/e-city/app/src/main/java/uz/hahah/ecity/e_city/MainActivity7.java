package uz.hahah.ecity.e_city;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

import uz.hahah.ecity.e_city.adapter.FragmentAdapter;
import uz.hahah.ecity.e_city.fragment.ProblemListFragment;
import uz.hahah.ecity.e_city.fragment.ProblemListFragmentForAuthority;
import uz.hahah.ecity.e_city.fragment.ProblemMapFragmentWithoutButton;
import uz.hahah.ecity.e_city.model.Problem;
import uz.hahah.ecity.e_city.model.User;
import uz.hahah.ecity.e_city.util.LocaleUtils;

public class MainActivity7 extends AppCompatActivity { //=MA3


    public Spinner category;
    public Spinner districts;
    private ViewPager viewPager;
    private TabLayout tabLayout;
    private TextView solvedProblems;
    private DrawerLayout mDrawerLayout;
    private NavigationView mNavigationView;
    private ActionBarDrawerToggle mToggle;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, (List<String>) category);
        //ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, (List<String>) districts);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        category = findViewById(R.id.secect_a_category);
        districts = findViewById(R.id.select_a_region);
        viewPager = findViewById(R.id.viewpager);
        tabLayout = findViewById(R.id.tabs);
        solvedProblems = findViewById(R.id.solved_problems);
        mDrawerLayout = findViewById(R.id.drawer);
        mNavigationView = findViewById(R.id.navigation_view);
        mAuth = FirebaseAuth.getInstance();
/*
        mToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.open, R.string.close);
        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();*/
        tabLayout.setupWithViewPager(viewPager);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        viewPager.setAdapter(new FragmentAdapter(getSupportFragmentManager())
                .addFragment(new ProblemMapFragmentWithoutButton(), getString(R.string.fragment_map))
                .addFragment(new ProblemListFragment(), getString(R.string.fragment_list))
        );
        districts.setSelection(0);
        category.setSelection(0);

       // mNavigationView.setNavigationItemSelectedListener((NavigationView.OnNavigationItemSelectedListener) this);

        districts.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // показываем позиция нажатого элемента
                Toast.makeText(getBaseContext(), "Position = " + position, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int pos, long id) {
                // показываем позиция нажатого элемента
                Toast.makeText(getBaseContext(), "Position = " + pos, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        FirebaseDatabase.getInstance()
                .getReference("problems")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        long count = dataSnapshot.getChildrenCount();
                        solvedProblems.setText(count + " of problems");
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(MainActivity7.this, "Error getting count!", Toast.LENGTH_SHORT).show();
                    }
                });



    }

  /*  @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    } */

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


/*  @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.fi:
                startActivity(new Intent(this, MainActivity3.class));
                break;
            case R.id.si:
                AlertDialog.Builder a_builder = new AlertDialog.Builder(this);

                a_builder.setTitle(R.string.rules_title)
                        .setMessage(R.string.Rules_text)
                        .setNeutralButton("Ok!", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }

                        }).create().show();
                break;
            case R.id.ti:
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity7.this);
                builder.setTitle(R.string.Languages);
                builder.setItems(new String[]{
                        getString(R.string.action_language_en),
                        getString(R.string.action_language_ru),
                        getString(R.string.action_language_uz),
                }, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        switch (i) {
                            case 0:
                                LocaleUtils.updateLanguage(MainActivity7.this, "en");
                                recreate();
                                break;

                            case 1:
                                LocaleUtils.updateLanguage(MainActivity7.this, "ru");
                                recreate();
                                break;
                            case 2:
                                LocaleUtils.updateLanguage(MainActivity7.this, "uz");
                                recreate();
                                break;
                        }
                    }
                });
                builder.create().show();
                break;
            case R.id.fhi: {
                mAuth.signOut();
                startActivity(new Intent(this, MainActivity1.class));
                break;
            }

        }

        return true;
    } */

}



